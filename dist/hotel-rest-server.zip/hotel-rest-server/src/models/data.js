let users = [
    {   
        "id" : 1,
        "name" : "aditya",
        "phone" : 1234,
        "email" : "aditya1234@domain.com",
        "bookings": [],
        "bonus_points" : 1500,
        "gender": "M"
    },
    {   
        "id" : 2,
        "name" : "ram",
        "phone" : 4321,
        "email" : "ram4321@domain.com",
        "bookings": [],
        "bonus_points" : 2500,
        "gender": "M"
    },
    {   
        "id" : 3,
        "name" : "radha",
        "mobile" : 6789,
        "email" : "radha6789",
        "bookings": [],
        "bonus_points" : 500,
        "gender": "F"
    }
];

let hotels = [
    {
        "id" : 1,
        "total_rooms": 5,
        "available_rooms": 2,
        "room_price": 500,
        "name": "Taj mahal palace",
        "address": "Apollo bandar, colaba, Mumbai",
        "rooms": [
            { "id" : 1 , "status" : "AVAILABLE"},
            { "id" : 2 , "status" : "AVAILABLE"},
            { "id" : 3 , "status" : "BOOKED"},
            { "id" : 4 , "status" : "BOOKED"},
            { "id" : 5 , "status" : "BOOKED"}
        ]
    },
    {
        "id" : 2,
        "total_rooms": 5,
        "available_rooms": 3,
        "room_price": 800,
        "name": "Hyatt regency",
        "address": "Hinjewadi phase1, Pune",
        "rooms": [
            { "id" : 1 , "status" : "AVAILABLE"},
            { "id" : 2 , "status" : "AVAILABLE"},
            { "id" : 3 , "status" : "AVAILABLE"},
            { "id" : 4 , "status" : "BOOKED"},
            { "id" : 5 , "status" : "BOOKED"}
        ]
    }
];

let bookings = [
    
];