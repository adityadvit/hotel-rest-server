//import data from './models/data';
import _ from 'lodsh';

//Move data handling to models
let users = [
    {   
        "id" : 1,
        "username" : "aditya",
        "phone" : 1234,
        "email" : "aditya1234@domain.com",
        "bookings": [],
        "bonus_points" : 1500,
        "gender": "M"
    },
    {   
        "id" : 2,
        "username" : "ram",
        "phone" : 4321,
        "email" : "ram4321@domain.com",
        "bookings": [],
        "bonus_points" : 2500,
        "gender": "M"
    },
    {   
        "id" : 3,
        "username" : "radha",
        "mobile" : 6789,
        "email" : "radha6789",
        "bookings": [],
        "bonus_points" : 500,
        "gender": "F"
    }
];

let rooms = [
    {
        "id": 1,
        "status": "AVAILABLE",
        "hotel_id": 1
    },
    {
        "id": 2,
        "status": "AVAILABLE",
        "hotel_id": 1
    },
    {
        "id": 3,
        "status": "BOOKED",
        "hotel_id": 1
    },
    {
        "id": 4,
        "status": "BOOKED",
        "hotel_id": 1
    },
    {
        "id": 5,
        "status": "BOOKED",
        "hotel_id": 1
    },
    {
        "id": 6,
        "status": "AVAILABLE",
        "hotel_id": 2
    },
    {
        "id": 7,
        "status": "AVAILABLE",
        "hotel_id": 2
    },
    {
        "id": 8,
        "status": "AVAILABLE",
        "hotel_id": 2
    },
    {
        "id": 9,
        "status": "BOOKED",
        "hotel_id": 2
    },
    {
        "id": 10,
        "status": "BOOKED",
        "hotel_id": 2
    },
    {
        "id": 11,
        "status": "AVAILABLE",
        "hotel_id": 3
    },
    {
        "id": 12,
        "status": "AVAILABLE",
        "hotel_id": 3
    },
    {
        "id": 13,
        "status": "AVAILABLE",
        "hotel_id": 3
    }

];

let hotels = [
    {
        "id" : 1,
        "room_price": 500,
        "name": "Taj mahal palace",
        "address": "Apollo bandar, colaba, Mumbai"
    },
    {
        "id" : 2,
        "room_price": 800,
        "name": "Hyatt regency",
        "address": "Hinjewadi phase1, Pune"
    }
];

let bookings = [
    
];

export function index(req, res) {
    res.json({
        "status": "success",
        "data": hotels
    });
}

export function view(req, res) {
    var hotel_id = parseInt(req.params.hotel_id);
    var _hotel = hotels.filter(function(h) {
        if(h.id === hotel_id) return h;
    });
    if(_hotel.length){
        res.json({
            "status": "success",
            data: _hotel
        })
    } else {
        res.status(404)
            .json({
                "status" : "failure",
                "message" : "Hotel with id=" + hotel_id + "not found"
            });
    }
}

export function update(req, res) {
    var hotel_id = parseInt(req.params.hotel_id);
    var username = req.query.username;
    //var days = parseInt(req.query.days)
    
    if(hotel_id == "" || hotel_id == null ) {
        res.status(400)
        .json({
            "status": "failure",
            "message" : "hotel id is null"
        });    
    }
    if(username == "" || username == null ) {
        res.status(400)
        .json({
            "status": "failure",
            "message" : "username is null"
        });    
    }
    
    //TBD: Move data handling to the central place -- use models
    var _hotel = hotels.filter(function(h) {
        if(h.id === hotel_id) return h;
    });

    if(! _hotel.length){
        res.status(404)
        .json({
            "status" : "failure",
            "message" : "Hotel with id=" + hotel_id + "not found"
        });
    }

    var _user = users.filter(function(u){
        if(u.username == username) return u;
    });

    if(! _user.length){
        res.status(404)
        .json({
            "status" : "failure",
            "message" : "user with username=" + username + "not found"
        });
    }

    //Check if the hotel room/rooms are available
    var _availebeRooms = rooms.filter(function(r){
        if(r.status === "AVAILABLE" && r.hotel_id === hotel_id) return r;
    });

    if(!_availebeRooms.length){
        res.status(428) //precondition required
        .json({
            "status": "failure",
            "message": "rooms not available in the hotel with id=" + hotel_id
        })
    }

    var _hotelPrice = _hotel[0].room_price;
    var _userBonusPoint = _user[0].bonus_points;
    var _roomToBeBooked = _availebeRooms[0];

    //TBD: craete new booking
    if(_userBonusPoint >= _hotelPrice){
        //update the room status to BOOKED
        rooms.forEach(function(r) {
            if((r.hotel_id == hotel_id) && (_roomToBeBooked.id == r.id)){
                r.status = "BOOKED";
                break;
            }
        });
        //update user bonus points
        users.forEach(function(u){
            if(u.username == username){
                u.bonus_points = u.bonus_points - _hotelPrice;
                break;
            }
        });
        res.json({
            "result": "success",
            "message": username + " has successfully booked the room with id=" + _roomToBeBooked.id + 
                " in hotel named " + _hotel.name
        });
        
    } else {
        //update the room status to PENDING_APPROVAL
        rooms.forEach(function(r) {
            if((r.hotel_id == hotel_id) && (_roomToBeBooked.id == r.id)){
                r.status = "PENDING_APPROVAL";
                break;
            }
        });
        //update user bonus points
        users.forEach(function(u){
            if(u.username == username){
                //Negative bonus points indicate points should be added by the user
                u.bonus_points = u.bonus_points - _hotelPrice;
                break;
            }
        });
        res.json({
            "result": "partial success",
            "message": username + " has to add" + u.bonus_points + " bonus points to book the room with id=" + _roomToBeBooked.id + 
                " in hotel named " + _hotel.name
        });
    }
}